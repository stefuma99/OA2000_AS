package a4binfo.oa2000_as;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import android.os.Environment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CLettura {

    CRecord record;
    Vector vett;
    InputStreamReader flusso;
    String filename;
    String[] valori;
    int pos, numeroSplit;

    public CLettura() {
        pos = 0;
        numeroSplit = CRecord.numValori;
        record = new CRecord();
        vett = new Vector();

    }

    public void read(String nameFile, String Operatore) {
        // si recupera il pathname completo del file all'interno della directory Downloads
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), nameFile);

        BufferedReader buffreader;
        // si apre il file in lettura e si copiano tutte le informazioni in codici

        try (FileReader reader = new FileReader(file)) {
            buffreader = new BufferedReader(reader);

            try {
                String line;

                line = buffreader.readLine();

                while (line != null) {

                    record = new CRecord();
                    record.parseString(line, ";");
                    String s = record.getValoreInd(CRecord.TECNICO);
                    if (Operatore.compareTo(s)==0) {
                        vett.add(record);
                    }
                    line = buffreader.readLine();
                }
            } finally {
                try {
                    buffreader.close();
                } catch (IOException ex) {
                    Logger.getLogger(CLettura.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(CLettura.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void CreateFile(String nameFile, String Operatore) {
        // il file non esiste per cui si deve creare il file
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), nameFile);

        try {
            // si crea il file, lo si apre in scrittura e si scrivono tutte le informazioni
            file.createNewFile();
            FileWriter writer = new FileWriter(file);
            BufferedWriter buffreader = new BufferedWriter(writer);
            buffreader.write("Chiamata Nø;Data;Tecnico;Contratto;Commessa;Impianto;Codice;Cliente;Telefono;E-mail;Contatto;Riferimenti;Richiesta del cliente;Presso;Tipo intervento;Indirizzo e-mail:;idriga;;;;;;;;;\n" +
                    "20171027;2017-04-03T22:00:00.000Z;XPIF;P;2014/1047;;0747;WORK SVILUPPO;;;;;prova scrittura sheets;Ns. Uffici Via Indipendenza 44 Meda -;Dal cliente;xpif@oa2000.com;32361;;;;;;;;;\n" +

                    "2017989;2017-04-04T22:00:00.000Z;XPIF;C2013/15;2017/1680;;0625;MASPERO ;;;;;Quanto: impostare nella stampa del DDT la possibilit… di escludare dalla stampa alcune righe del documento;PAINA DI GIUSSANO  - VIA SALVO D'ACQUISTO 29;Dal cliente;xpif@oa2000.com;32248;;;;;;;;;\n" +

                    "20171001;2017-04-04T22:00:00.000Z;XPIF;P;2015/1398;;0922;TOSI;;;;;WORKi: Aggiornamento stampe coop;VENTURINA  - VIA DELL'INDUSTRIA 10;Dal cliente;xpif@oa2000.com;32265;;;;;;;;;\n" +

                    "2017939;2017-04-04T22:00:00.000Z;XPIF;P;2012/45;;1072;OA2000 AMMINISTRAZIONE;;gerosa@oa2000.com;;;daniela analisi per visualizzare nelle schede ore, le righe di chiusura chiamate con pi— testo;Uffici Via Indipendenza Meda -;Dal cliente;xpif@oa2000.com;32161;;;;;;;;;\n" +

                    "20171021;2017-04-09T22:00:00.000Z;XPIF;P;2012/45;;1072;OA2000 AMMINISTRAZIONE;;gerosa@oa2000.com;;;Programma fatturazione schede ore/impostare una data univoca per tutte le righe;Uffici Via Indipendenza Meda -;Dal cliente;xpif@oa2000.com;32352;;;;;;;;;\n" +

                    "20171023;2017-04-05T22:00:00.000Z;XSTE;P;2012/30;;0633;OA2000 COMMERCIALE;;gerosa@oa2000.com;;;Nuovo regolamento europeo Privacy;Ns.Uffici Via Indipendenza 44 Meda -;In sede;xste@oa2000.com;32355;;;;;;;;;");

            buffreader.close();

        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    CRecord getRecord(int ind) {
        return (CRecord) vett.get(ind);
    }

    public String toString() {
        String linea = "";
        for (int i = 0; i < vett.size(); i++) {
            CRecord cr = (CRecord) vett.get(i);
            linea += cr.toString("\n");
        }
        return linea;
    }

    public int numInterventi() {
        return vett.size();
    }
}

