package a4binfo.oa2000_as;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;

import static a4binfo.oa2000_as.R.id.editText1;
import static a4binfo.oa2000_as.R.styleable.CompoundButton;

public class ActivityInvioFirme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_invio_firme);

        final EditText liberaText1 = (EditText) findViewById(R.id.editText1);
        final EditText liberaText2 = (EditText) findViewById(R.id.editText2);

        CheckBox libera1 = (CheckBox) findViewById(R.id.checkBox5);
        libera1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (((CheckBox) v).isChecked()) {
                    liberaText1.setEnabled(true);
                    liberaText1.requestFocus();
                }
                else
                {
                    liberaText1.setEnabled(false);
                }
            }
        });

        CheckBox libera2 = (CheckBox) findViewById(R.id.checkBox6);
        libera2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (((CheckBox) v).isChecked()) {
                    liberaText2.setEnabled(true);
                    liberaText2.requestFocus();
                }
                else
                {
                    liberaText2.setEnabled(false);
                }

            }
        });
    }
}
