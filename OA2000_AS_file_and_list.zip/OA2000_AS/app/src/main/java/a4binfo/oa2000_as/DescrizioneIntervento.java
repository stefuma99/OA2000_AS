package a4binfo.oa2000_as;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class DescrizioneIntervento extends AppCompatActivity {
    CRecord record;
    EditText txt_Intervento,txt_nome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.descrizione_intervento);

        record = ActivityLogin.lett.getRecord(ActivityLogin.interventoSelezionato);

        String cliente = record.getValoreInd(CRecord.CLIENTE);
        String descrizione = record.getValoreInd(CRecord.RICHIESTACLIENTE);

        txt_nome=(EditText) findViewById(R.id.editText5);
        txt_Intervento=(EditText) findViewById(R.id.editText6);
        txt_nome.setText(cliente);
        txt_Intervento.setText(descrizione);
    }
}
