package a4binfo.oa2000_as;

// http://www.corsoandroid.it/listview_per_creare_liste_di_dati_in_android.html

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    TextView dati;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //eliminazione barra alto

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_menu);
        dati = (TextView) findViewById(R.id.ActMenuDati);

        // definisco un ArrayList
        final ArrayList<String> listp = new ArrayList<String>();
        for (int i = 0; i < ActivityLogin.lett.numInterventi(); ++i) {
            CRecord record = ActivityLogin.lett.getRecord(i);
            String intervento = record.getValoreInd(CRecord.DATA) +
                    " " + record.getValoreInd(CRecord.CLIENTE) +
                    " " + record.getValoreInd(CRecord.TIPODIINTRVENTO) +
                    " " + record.getValoreInd(CRecord.PRESSO);
            listp.add(intervento);
        }
        // recupero la lista dal layout
        final ListView mylist = (ListView) findViewById(R.id.listViewInterventi);

        // creo e istruisco l'adattatore
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listp);

        // inietto i dati
        mylist.setAdapter(adapter);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener()

                               {
                                   @Override
                                   public void onClick(View view) {
                                       Intent openInputActivity = new Intent(MenuActivity.this, Rapporto.class);
                                       startActivity(openInputActivity);
                                   }
                               }

        );

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adattatore, final View componente, int pos, long id){
                // recupero il titolo memorizzato nella riga tramite l'ArrayAdapter
                // final String titoloriga = (String) adattatore.getItemAtPosition(pos);
                // Log.d("List", "Ho cliccato sull'elemento con titolo" + titoloriga);
                ActivityLogin.interventoSelezionato = pos;
                CRecord record = ActivityLogin.lett.getRecord(ActivityLogin.interventoSelezionato);
                String intervento = record.getValoreInd(CRecord.DATA) +
                        "    " + record.getValoreInd(CRecord.CLIENTE) +
                        "    " + record.getValoreInd(CRecord.RICHIESTACLIENTE) +
                        "    " + record.getValoreInd(CRecord.CONTATTO) +
                        "    " + record.getValoreInd(CRecord.NCHIAMATA) +
                        "    " + record.getValoreInd(CRecord.PRESSO);
                dati.setText(intervento);
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //LOGOUT
        //noinspection SimplifiableIfStatement
        //if (id == R.id.action_settings) {
        //return true;
        //}

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.invia_rapporto) {
            Intent openInputActivity = new Intent(MenuActivity.this, ActivityInvioFirme.class);
            startActivity(openInputActivity);
        } else if (id == R.id.aggiungi_descrizione) {
            Intent openInputActivity = new Intent(MenuActivity.this, DescrizioneIntervento.class);
            startActivity(openInputActivity);
        } else if (id == R.id.spese_intervento) {
            Intent openInputActivity = new Intent(MenuActivity.this, Intervento1.class);
            startActivity(openInputActivity);
        } else if (id == R.id.cerca_appuntamenti) {

        } else if (id == R.id.cerca_colleghi) {


        } else if (id == R.id.gestione_profilo) {
            Intent openInputActivity = new Intent(MenuActivity.this, ProfiloActivity.class);
            startActivity(openInputActivity);
        } else if (id == R.id.menu_logout) {
            final Button btnLogout = (Button) findViewById(R.id.ActivityLoginBtnLogin);
            btnLogout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btnLogout.setBackgroundResource(R.drawable.bottoneloginclicked);
                    Intent openInputActivity = new Intent(MenuActivity.this, ActivityLogin.class);
                    startActivity(openInputActivity);
                }

            });
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
