package a4binfo.oa2000_as;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityLogin extends AppCompatActivity {

    static public CLettura lett;
    static public int interventoSelezionato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        lett = new CLettura();
        lett.CreateFile("elenco_interventi.csv","XPIF");
        lett.read("elenco_interventi.csv","XPIF");
        interventoSelezionato = 0;

        //record.setValore("NOTECLIENTEDALFILE", CRecord.CLIENTE);
        //record.setValore("RICHIESTACLIENTEDALFILE", CRecord.RICHIESTACLIENTE);

        final Button btnLogin = (Button) findViewById(R.id.ActivityLoginBtnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    btnLogin.setBackgroundResource(R.drawable.bottoneloginclicked);
                Intent openInputActivity = new Intent(ActivityLogin.this, MenuActivity.class);
                startActivity(openInputActivity);
                }

        });
    }
}
